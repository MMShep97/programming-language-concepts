#!/bin/sh

gcc -o task2 task2.c
gcc -o task3 task3.c