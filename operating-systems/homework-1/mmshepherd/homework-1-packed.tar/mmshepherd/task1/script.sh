#!/bin/sh
find "$1" -type f -name "*.$2"