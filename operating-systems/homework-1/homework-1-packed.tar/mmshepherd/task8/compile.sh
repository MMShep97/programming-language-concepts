#!/bin/sh
gcc -o task8 task8.c