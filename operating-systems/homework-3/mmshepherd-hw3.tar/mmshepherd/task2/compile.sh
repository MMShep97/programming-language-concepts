#!/bin/bash
gcc task2.c -o task2
