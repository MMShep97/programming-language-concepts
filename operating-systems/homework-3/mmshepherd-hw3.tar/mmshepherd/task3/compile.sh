#!/bin/bash
gcc task3.c -o task3
